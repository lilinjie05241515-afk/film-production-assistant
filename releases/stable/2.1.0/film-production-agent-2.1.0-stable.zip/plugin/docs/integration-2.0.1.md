# 2.0.1 跨平台维护与发行

本版接续 2.0.0 双主题创作看板，作为新的不可变稳定版本。保留独立导演、完整预演审看、看板只读更新、分层会话和准确版本决定，不改写既有作品、聊天关联或任务执行锁。旧 2.0.0 开发包与更早稳定发行分别留存。

## 版本检查

运行模块、插件清单与看板须报告 `2.0.1`。完整安装包应包含 26 个工具、8 个专业方法模块、5 个公开技能入口；方法文件与模块清单摘要匹配。安装器 materialize 后的 `.mcp.json` 使用目标机器的绝对 Python 和脚本路径，其余受保护文件保持发行摘要。

## Mac 运行范围

Windows 与 macOS 使用同一稳定 ZIP。Mac 安装和更新步骤见 [MACOS.md](MACOS.md)，包括 Python 3.11+、sqlite3、中文/空格路径、FFmpeg/FFprobe 和可选 Blender。安装器不自动安装依赖，不复制作品，不把开发者的持续授权传播给其他使用者。

Mac 默认 catalog 和显式路径配置分开；Finder 启动可能缺少 Terminal 的 PATH，媒体工具按实际可运行的路径查找。测试片的水印要求继续保留，缺少必要滤镜应报错，不去掉水印后伪装成功。新环境须通过安装器生成本机配置，不能直接沿用 Windows 盘符和可执行文件。

## 验证与证据

对应源提交由 [跨平台 CI](https://github.com/lilinjie05241515-afk/film-production-assistant/actions/workflows/compatibility.yml) 在 Windows、Apple Silicon Mac 与 Intel Mac 执行。检查后端工作流、安装/发行工具、全部当前看板交互，以及实际解压安装包的独立 stdio、合成项目写入读回和媒体运行。两类 Mac 还实际执行包内 Blender 双视角预演、解码校验，并重新打开工程检查镜头切换和角色运动；为无 GPU 的测试环境显式选择 Cycles CPU，默认 Workbench 不变。冻结 ZIP 还需与从源码重建的 payload 逐项匹配。

本文件说明验收方法，不提前声明当前检查成功。实际通过状态、所测提交和冻结 ZIP SHA-256 以本版 GitHub Release 的验证记录为准。测试只用独立 TEST/synthetic 数据；包内合成渲染成功不代表画面效果或真实作品获批。

Mac 原生客户端面板、真实用户对话和个人机器上的插件发现未由上述测试替代。首次接入后在新会话核实 `film_health`、模块、看板及实际媒体；已有聊天可继续运行其原先加载的固定版本。
